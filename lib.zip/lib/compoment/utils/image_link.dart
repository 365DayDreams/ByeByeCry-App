
const playButton = "asset/images/PlayButton.png";
const playButtonSvg = "asset/images/playbutton_svg.svg";
const whitePlus = "asset/images/WhitePlus.png";
const deleteSvg = "asset/images/delete bin_.svg";
const pouseButton = "asset/images/PouseButton.svg";
const arrow_foreword = "asset/images/Arro_foreword.svg";
const timer = "asset/images/icon_png/timer1.svg";
const volume = "asset/images/icon_png/volumehigh.svg";
const right_shift = "asset/images/right_shif.svg";
const left_shift = "asset/images/left_shift.svg";
const down_arrow = "asset/images/down_arrow.svg";
const profile = "asset/images/Profile.svg";
const leftDirection = "asset/images/icon_png/left_direction.svg";
const rightDirection = "asset/images/icon_png/right_direction.svg";
const loveSvg = "asset/images/icon_png/love.svg";
const sleep_baby = "asset/images/sleep_baby.png";
const homesleep_baby = "asset/images/homeslwwp_baby.jpg";
const crossButtom = "asset/images/CrossComponent.svg";
const chainsaw = "asset/images/sounds_image/Chainsaw.png";
const vaccum = "asset/images/sounds_image/Vaccum.png";
const jackhammer = "asset/images/sounds_image/Jackhammer.png";
const blowdryer = "asset/images/sounds_image/Blowdryer.png";
const lawnmower = "asset/images/sounds_image/Lawnmower.png";
const washer = "asset/images/sounds_image/Washer.png";
const ocean = "asset/images/sounds_image/Ocean.png";
const dummy = "asset/images/sounds_image/dummy.png";
const music = "asset/images/icon_png/sound_color.png";
const logo= "asset/images/Logo.png";
const musicJust = "asset/images/music.svg";


// New 21 Sound Image...

const Blender = "asset/images/sounds_image/Blender.jpg";
const BrwonNoise = "asset/images/sounds_image/BrownNoise.jpg";
const Chainsawww = "asset/images/sounds_image/Chainsaw.jpg";
const ClassiCal = "asset/images/sounds_image/Classical.jpg";
const Dryer = "asset/images/sounds_image/Dryer.jpg";
const FAN = "asset/images/sounds_image/Fan.jpg";
const Garbage = "asset/images/sounds_image/GarbageDisposal.jpg";
const HAirDryer = "asset/images/sounds_image/Hairdryer.jpg";
const LawnMower = "asset/images/sounds_image/Lawnmower.jpg";
const LeafBlower = "asset/images/sounds_image/leaf-blower.jpg";
const LeafBower = "asset/images/sounds_image/Lawnmower.jpg";
const Ocean = "asset/images/sounds_image/Ocean.jpg";
const PinkNoise = "asset/images/sounds_image/PinkNoise.jpg";
const Rain = "asset/images/sounds_image/Rain.jpg";
const ShopVac = "asset/images/sounds_image/ShopVac.jpg";
const SuShing = "asset/images/sounds_image/Shushing.jpg";
const Vaccum = "asset/images/sounds_image/Vacuum.jpg";
const VacuumMoving = "asset/images/sounds_image/VacuumMoving.jpg";
const Washer = "asset/images/sounds_image/Washer.jpg";
const WeedWacker = "asset/images/sounds_image/Weedwacker.jpg";
const WhiteNoise = "asset/images/sounds_image/WhiteNoise.jpg";
const JackMmer = "asset/images/sounds_image/Jackhammer.jpg";






