const entielementid = "premium";


 const googleAPIKey = "goog_ATlRuyFtApdDQfymZosARUNmzGv";
 const iosAPIKey = "appl_gzYYTbQFHkHURMuVDlyBrnuHoBB";
